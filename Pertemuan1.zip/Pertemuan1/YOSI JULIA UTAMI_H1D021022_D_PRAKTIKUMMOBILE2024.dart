// Mendefinisikan kelas Mobil
class Mobil {
  // Property (atribut) kelas Mobil
  String merk;
  String model;
  int tahun;

  // Constructor untuk menginisialisasi objek Mobil
  Mobil(this.merk, this.model, this.tahun);

  // Method untuk menampilkan informasi tentang mobil
  void tampilkanInfo() {
    print('Mobil: $merk $model ($tahun)');
  }

  // Method untuk menyalakan mobil
  void nyalakanMesin() {
    print('Mesin $merk $model dinyalakan.');
  }

  // Method untuk mematikan mobil
  void matikanMesin() {
    print('Mesin $merk $model dimatikan.');
  }
}

void main() {
  // Membuat objek Mobil
  Mobil mobil1 = Mobil('Toyota', 'Avanza', 2020);
  Mobil mobil2 = Mobil('Honda', 'Civic', 2019);

  // Memanggil method dari objek mobil1
  mobil1.tampilkanInfo();
  mobil1.nyalakanMesin();
  mobil1.matikanMesin();

  // Memanggil method dari objek mobil2
  mobil2.tampilkanInfo();
  mobil2.nyalakanMesin();
  mobil2.matikanMesin();
}
